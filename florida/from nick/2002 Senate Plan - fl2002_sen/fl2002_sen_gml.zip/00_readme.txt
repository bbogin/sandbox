District Builder exports plans into three formats:

BLOCK ASSIGNMENT FILE - This is the block-level ASCII file in the format 
prescribed by the United States Department of Justice (see, 28 CFR 51.28). 
There is one record for each block in the plan.  Block Assignment File usually 
is the best choice for export. It is compatible with most redistricting applications.

GML - This format describes the geometric shapes of districts in GML (Geographic 
Markup Language). GML is compatible with geographic information systems such 
as ArcGIS, Maptitude, and Quantum GIS. Each district has one or more shapes. 
The ZIP archive for a GML export contains two files other than the readme file: 
(1) planname.gml with vertices, and (2) planname.xsd with schema information.  
Both are required to import the shapes into a geographic information system. GML 
exports CANNOT be imported into District Builder.

KML - This format describes the geometric shapes of districts in KML (Keyhole 
Markup Language). KML is compatible with Google Maps, Google Earth, and 
Quantum GIS. Like with GML, each district has one or more shapes. KML exports 
CANNOT be imported into District Builder.

